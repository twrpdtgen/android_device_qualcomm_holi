a.GQ
